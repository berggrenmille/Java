package edu.mille.java.uppgifter;

public class U1_2 {
    public static void main(String[] args) {
        System.out.println("Maximiliam");
        System.out.println("Berggren\n");
        System.out.println("Söderskogsvägen 9");
    }
}
