package edu.mille.java.uppgifter;

public class U1_3 {
    public static void main(String[] args) {
        System.out.println("JJJJJ   JJJ   J   J   JJJ");
        System.out.println("    J  J   J  J   J  J   J");
        System.out.println("    J  J   J   J J   J   J");
        System.out.println("J   J  JJJJJ   J J   JJJJJ");
        System.out.println(" JJJ   J   J    J    J   J");
    }
}
