package edu.mille.java.uppgifter;

public class U1_1
{
    public static void main(String[] args)
    {
        System.out.println("Maximiliam");
        System.out.println("Berggren");
        System.out.println("Söderskogsvägen 9");
    }
}
