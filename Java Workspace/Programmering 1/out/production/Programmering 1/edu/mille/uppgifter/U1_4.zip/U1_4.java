package edu.mille.java.uppgifter;

public class U1_4 {
    public static void main(String[] args) {
        System.out.println("  \" \" \" " );
        System.out.println("\\ \\   / /");
        System.out.println("  O   O");
        System.out.println("    U");
        System.out.println("   ___");
    }
}
